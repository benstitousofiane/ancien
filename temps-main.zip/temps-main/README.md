# temps⌚
Gestionnaire de temps pour la productivité

**Utilisation et droit :** Tout libre de droit, même pour des raison commerciale et pour de la redistribution sans mention !
Pour le moment pas de responsive !

# Fonctionnalités :

**Minuteur** : Ajouter son temps, le lancer, mettre pause le réinitialiser avec 'reset'.. Un simple mais beau minuteur.

**Chronomètre** : Meusurer le temps de votre travail en cliquant sur 'start', mettre pause au chronomètre avec 'pause' et le réinitialiser avec 'reset'.

# boycott📨
Ma première appli web avec une base de donnée, un simple chat.

Pour des raison de responsabilités, je n'hébergerait pas moi-même cette appli.

Je décline toute responsabilité quand à son utilisation libre de droit.

# Instruction pour l'héberger :
1. Avoir un serveur web avec apache, php et un gestionnaire de base de donnée, j'utilise phpmyadmin.

2. Importer le fichier SQL sous une bases de donnée nommé "boycott"

3. Mettre tout les fichier sous un dossier comme "www" sur votre serveur web.

4. Modifier si besoin le fichier "db.php" pour faire la connexion avec la base de donnée MySQL

5. Aller vers l'url de votre page web et profité ! :D

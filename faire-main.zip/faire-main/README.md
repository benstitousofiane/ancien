# faire✅
Ma propre application type "to-do list"

# Fonctionnalités
**+** : ajouter une tâche après avoir écrit sur l'entrée utilisateur

**click** : barré la tâche quand elle est terminé

**double click** : retirer la tâche effectuer

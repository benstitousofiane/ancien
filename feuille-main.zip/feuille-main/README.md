# feuille🍃
un simple papier cailloux ciseaux contre ordinateur.

Libre de droit.


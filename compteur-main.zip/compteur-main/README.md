# compteur1️⃣
Ma toute première application web, simple et efficace.

# Les fonctionnalités

**+1** : ajouter 1 au compteur
**-1** : enlever 1 au compteur
**à 0** : remettre le compteur à zero

Un petit pas pour l'humanité, mais un grand pas pour l'homme que je deviendrai 🤯

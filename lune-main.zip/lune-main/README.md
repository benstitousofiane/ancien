# lune🌙
C framework to easily create semi-graphic or mathematical programs

➡️ lune : the programs and modules manager ♻️.

➡️ maniaque : a from scratch math lib 🔢✨.

➡️ estampe : the semi-graphic lib for lune 📜📈.

## In basics (maniaque_...) :
- identity : return the number itself
- sum : sum two numbers
- minus : substract two numbers
- multiplication : multiply two numbers
- division : divide two numbers
- opposite : get the opposite of an number
- inverse : get the inverse of an number
- absolute : get the absolute value of an number
- powerInt : return que number multiplier itselft n times
- powerFracInt : return the number with a fraction power
- factorial : return the factorial of an numebr
- square : return the square of an number
- cube : return the cube of an number
- sqrt : return the square root of an number
- cuberoot : return the cube root of an number
- nthroot : return the n th root of an number
- GaussSum : sum from 1 to n
- sin : return the sinus of an number (rad)
- cos : return the cos of an number (rad)
- tan : return the tan of an number (rad)


//Développed by Benstitou Sofiane
//Start the 7 october 2023
//maniaque : my own math lib for projetcs


void lol(void){
    printf("\nlol\n");
}
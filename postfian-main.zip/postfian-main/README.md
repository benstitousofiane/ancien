# postfian
simple free CMS

En cours : Développement de l'éditeur d'article

Preview :

![image](https://github.com/benstitousofiane/postfian/assets/129552238/6a87c5ac-4bdd-44eb-b880-df25d9970361)

![image](https://github.com/benstitousofiane/postfian/assets/129552238/764bc0f7-c377-4b23-8179-6e5e61eaeb8f)

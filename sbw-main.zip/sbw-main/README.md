# sbw🪑
![image](https://github.com/benstitousofiane/sbw/assets/129552238/ca4ff8a4-bc3d-4dad-82eb-da9ca17fed46)

# Fonctionnalitées
- SBW : Mon site web où j'indexe mes différents projets
- Portinfo : Une page pour alimenté mon portfolio informatique
- Récréation : Un site de publication des divers cours, et devoirs avec mes réponses (exercices) que j'ai reçu et écris tout au long de l'année.

# Prochaînement :
- Ajout de descartes🃏 pour apprendre ses cours (accès anticipé) -> tout les projets de descates seront supprimés pour la version stable
  Réparer l'apparition en doublons des projets et coder la gestion des cartes
- Une liaison entre mes projets avec SBW.
- Ajout de l'application sable en outil principale après la liaison.
- Ajout d'une version majeur de LaCase pour "Maths & Recherche".

A faire pour l'hébergement :
- Améliorer le CMS pour pouvoir éditer plus facilement et rapidement des contenus

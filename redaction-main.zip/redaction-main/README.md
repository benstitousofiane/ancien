# redaction
Mon notebook pour rédiger des maths rapidement
Plus important à faire : faire les espaces avec les élément katex et faire "comprendre les espaces entre un \command{...}"

# LaCase📓

# LaCase V2 (bientôt...) ➡️ en test ici : https://benstitousofiane.github.io/lacase/lacasev2/
Un aperçu de supers nouveautés de LaCase V2 🤩🙈
![image](https://github.com/benstitousofiane/lacase/assets/129552238/a4546c00-4bd0-4f88-b9f9-ea763e0d1205)


# LaCase V1

![lacaseprofile](https://github.com/benstitousofiane/LaCase/assets/129552238/fbc9844b-1b1d-402e-9235-b1af93a57bb1)



Un magnifique notebook pour les maths !
Fonctionnement des version : X.P avec P un nomrbe premier

**0.2** : Simples entrée en latex

**0.3** : Grosse refonte du design de l'appli

**1.02** : Ajout du concept de l'application avec le design de la version 0.3
  Disponible functionalités pour le moment
  - **+T** : ajouté une case pour écrire du texte brute.
  - **+M** : ajouté une case de texte typz LaTeX pour vos formules mathématiques
  - **La** (après avoir cliqué sur +T ou +M) : afficher le contenue de la case

**1.03** : amélioration et ajout de praticité; pour le moment présent : suppression de textes ajoutése, amélioration la taille des texterea, et amélioration du style
  fonctionalités ajoutées :
  - supression de texte ajouté : "double click" sur une phrase ajouté et il sera supprimé.
  A CORRIGE !!! : mettre en place la suppression des textes pour n'importe quelle case après lajout de plusieurs text

**1.05** (ECDD) : Ajout des racourcis:
  - **T** : Ajouté du text
  - **M** : Ajouter une formule mathématiques
  - **SHIFT + ENTER** : Afficher le résultat de l'entré sur un textaraa (Raccourci pour le La Button)
  - **Taille des textarea agrendit**

bug à corriger sur le bindlocker quand on ajoute deux cases text et maths, faire deux variable exprès pour ça !

**Fonctionnalités qui marchent actuellement** (à modifier)
**Deux champs** :
  - Le champs texte brute : ajouté du texte avec votre police d'écriture modifiable sur le CSS
  - Le champs maths : là où vous écrivez vos formule mathémariques
  - **La** : Lacase key, lire afficher le contenue écrit dans le champt de texte et de maths.

Projet libre de droit pour n'importe quelle utilisation, même commercial !

Dépendances (importer sur le header de index.html) : KaTeX et son option de balise type math/tex
Magnifique et très pratique documentation du fonctionnement des commande LaTeX utilisé dans KaTeX : https://katex.org/docs/supported.html
